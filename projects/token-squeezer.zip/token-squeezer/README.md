# Token Squeezer
Local, model-agnostic prompt compression. Zero dependencies, Node >=20. Compression runs on your machine and costs 0 model tokens.

## Four savings layers
1. **Clean (lossless-ish, L1-L3):** whitespace/newline runs, smart quotes, JSON minify, markdown decoration, duplicate paragraphs across turns, filler phrases, code comments (L3). Honest range on already-clean prose: ~2-6%; on messy/PDF-extracted text more.
2. **Compact (lossy, query-aware):** old turns and large documents are pruned to the sentences most relevant to the current question (BM25-style scoring, keeps headings, definitions, numbers, first/last lines). Typically 50-90% on long context.
3. **Budget:** `maxInputTokens` escalates automatically: level 3, shrink old turns, prune biggest messages, omit oldest turns. The current user turn is never pruned unless nothing else fits.
4. **Cache + terse output:** repeated requests cost 0 tokens (LRU/TTL cache); optional "reply tersely" directive trims output tokens.

## Use
    node src/cli.js squeeze doc.txt --budget 1500 --query "what you will ask"   # compress a file, paste result into any AI
    node src/cli.js chat messages.json --preset max --budget 4000               # compress a chat array
    node src/cli.js bench a.md b.tex                                            # measure on your files
    SQUEEZE_UPSTREAM=https://api.openai.com SQUEEZE_PRESET=max SQUEEZE_TERSE=1 node src/cli.js serve
Then point any OpenAI- or Anthropic-compatible client at `http://127.0.0.1:8787` (it forwards your own auth header). For Mishrin Paradoxical Computer set `MISHRIN_DEFAULT_BASE_URL=http://127.0.0.1:8787/v1`.
Endpoints: `GET /squeeze/stats`, `POST /squeeze/preview` (dry run). Response headers: `x-squeeze-tokens-before/after/saved-tokens`, `x-squeeze-cache`.
Env: SQUEEZE_UPSTREAM, SQUEEZE_UPSTREAM_KEY, SQUEEZE_PRESET (light|balanced|max), SQUEEZE_MAX_INPUT_TOKENS, SQUEEZE_TERSE=1, SQUEEZE_CACHE=0, SQUEEZE_CACHE_FILE, SQUEEZE_CACHE_MAX_TEMP (default 0.3), SQUEEZE_TOKEN, PORT, HOST.

## Limits
- Token counts are heuristic estimates, not a real tokenizer; verify with your provider's usage numbers (`/squeeze/stats` also sums upstream-reported usage).
- Pruning is lossy: it can drop a fact the query did not hint at. Use `light` for exact-fidelity work. Not for math proofs or code you need verbatim.
- Provider-side prompt caching (stable prefixes) is complementary and not replaced by this.
- Streaming responses are passed through uncached. Images/tool-call blocks are forwarded untouched.
