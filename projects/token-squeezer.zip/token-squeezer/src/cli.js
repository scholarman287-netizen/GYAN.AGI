#!/usr/bin/env node
import fs from 'node:fs';
import { compressText, compress, estimateTokens, PRESETS } from './squeeze.js';
import { createProxy } from './proxy.js';

const [cmd, ...rest] = process.argv.slice(2);
const flag = (n, d) => { const i = rest.indexOf('--' + n); return i >= 0 ? rest[i + 1] : d; };
const files = rest.filter((a, i) => !a.startsWith('--') && !(rest[i - 1] || '').startsWith('--'));
const read = (f) => (f === '-' || !f ? fs.readFileSync(0, 'utf8') : fs.readFileSync(f, 'utf8'));
const help = `token-squeezer
  squeeze <file|-> [--level 1-3] [--query "..."] [--budget N]   compress a document/prompt; text->stdout, stats->stderr
  chat    <messages.json|-> [--preset light|balanced|max] [--budget N] [--terse 1]   compress a chat message array
  bench   <files...>                                             compare levels/presets on your own files
  serve   (env: SQUEEZE_UPSTREAM, SQUEEZE_PRESET, SQUEEZE_MAX_INPUT_TOKENS, SQUEEZE_TERSE, SQUEEZE_CACHE_FILE, PORT, HOST)`;

if (cmd === 'squeeze') {
  const r = compressText(read(files[0]), { level: +flag('level', 2), query: flag('query', ''), budget: +flag('budget', 0) });
  process.stdout.write(r.text + '\n'); console.error(JSON.stringify(r.stats));
} else if (cmd === 'chat') {
  const r = compress(JSON.parse(read(files[0])), { preset: flag('preset', 'balanced'), maxInputTokens: +flag('budget', 0), terse: flag('terse') === '1' });
  process.stdout.write(JSON.stringify(r.messages, null, 2) + '\n'); console.error(JSON.stringify(r.stats));
} else if (cmd === 'bench') {
  const row = (...c) => console.log(c.map((x, i) => String(x).padEnd(i ? 11 : 34)).join(''));
  row('file', 'tokens', 'L1', 'L2', 'L3', 'L3+50%budget');
  for (const f of files) {
    const t = fs.readFileSync(f, 'utf8'), b = estimateTokens(t);
    const p = (r) => `${r.stats.after} (-${r.stats.pct}%)`;
    row(f.split('/').pop().slice(0, 32), b, p(compressText(t, { level: 1 })), p(compressText(t, { level: 2 })), p(compressText(t, { level: 3 })), p(compressText(t, { level: 3, budget: Math.floor(b / 2), query: 'definition stability conditions' })));
  }
  console.log('Token counts are heuristic estimates; verify with your model\'s tokenizer.');
} else if (cmd === 'serve') {
  const { server } = createProxy(); const port = +(process.env.PORT || 8787), host = process.env.HOST || '127.0.0.1';
  if (!['127.0.0.1', '::1', 'localhost'].includes(host) && !process.env.SQUEEZE_TOKEN) { console.error('Refusing non-local bind without SQUEEZE_TOKEN'); process.exit(1); }
  server.listen(port, host, () => console.log(`token-squeezer proxy on http://${host}:${port} -> ${process.env.SQUEEZE_UPSTREAM || '(set SQUEEZE_UPSTREAM)'} presets=${Object.keys(PRESETS)}`));
} else console.log(help);
