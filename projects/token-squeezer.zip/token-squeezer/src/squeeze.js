// Token Squeezer core: model-agnostic prompt compression. Zero dependencies, runs locally (0 model tokens).
// Levels: 1 = near-lossless cleanup, 2 = + dedupe/markdown strip, 3 = + telegraphic prose & comment stripping.
// Pruning (query-aware extractive) is lossy and only applied to old turns, big documents, or when over budget.

const SLASH = new Set(['js', 'javascript', 'ts', 'typescript', 'java', 'c', 'cpp', 'go', 'rust', 'rs', 'swift', 'kotlin', 'cs', 'php', 'scala']);
const HASH = new Set(['py', 'python', 'sh', 'bash', 'shell', 'yaml', 'yml', 'rb', 'ruby', 'toml', 'r']);
const STOP = new Set('the and for with are was were been this that these those from not but then which who what when where how why you your they them his her our their its into about over under than also just very have has had can could will would should may might'.split(' '));

/** Approximate token count (no tokenizer needed). Calibrated to ~BPE behaviour; real counts vary by model. */
export function estimateTokens(s = '') {
  let t = 0;
  for (const m of String(s).matchAll(/\s*\n\s*|[ \t]{2,}|[\p{L}]+|\d+|([^\s\p{L}\d])\1*/gu)) {
    const x = m[0];
    if (/^\s/.test(x)) t += 1 + Math.floor(x.length / 24); // whitespace/newline runs cost ~1 token each
    else if (/[぀-鿿가-힯]/.test(x)) t += x.length;
    else if (/^\p{L}/u.test(x)) t += Math.max(1, Math.round(x.length / 4.2));
    else if (/^\d/.test(x)) t += Math.ceil(x.length / 3);
    else t += Math.ceil(x.length / 2);
  }
  return t;
}

function splitFences(text) {
  const out = []; let last = 0, m; const re = /```([^\n`]*)\n([\s\S]*?)```/g;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ code: false, text: text.slice(last, m.index) });
    out.push({ code: true, lang: m[1].trim().toLowerCase(), text: m[2] }); last = re.lastIndex;
  }
  if (last < text.length) out.push({ code: false, text: text.slice(last) });
  return out;
}
const joinFences = (parts) => parts.map((p) => (p.code ? '```' + p.lang + '\n' + p.text + '```' : p.text)).join('');
function tryJson(s) { const t = s.trim(); if (!/^[[{]/.test(t)) return null; try { return JSON.stringify(JSON.parse(t)); } catch { return null; } }

const ASCII = { '‘': "'", '’': "'", '“': '"', '”': '"', '–': '-', '—': '-', '…': '...', ' ': ' ', '•': '-' };
function prose1(t) {
  return t.replace(/[​-‍﻿]/g, '').replace(/[‘’“”–—… •]/g, (c) => ASCII[c])
    .replace(/<!--[\s\S]*?-->/g, '').replace(/[ \t]+$/gm, '').replace(/(\S)[ \t]{2,}/g, '$1 ')
    .replace(/^(?:[-*_][ \t]*){3,}$/gm, '').replace(/\n{3,}/g, '\n\n');
}
function prose2(t, role) {
  t = t.replace(/(\*\*|__)(?=\S)([\s\S]*?\S)\1/g, '$2')
    .replace(/^[ \t]*\|?[ \t:|-]*-{3,}[ \t:|-]*\|?[ \t]*$/gm, (r) => (r.includes('|') ? r.replace(/-{3,}/g, '-').replace(/[ \t]+/g, '') : r))
    .replace(/^(.+)\n\1$/gm, '$1');
  if (role === 'assistant') t = t.replace(/^(sure|certainly|of course|absolutely|great question)[!,.]\s*/i, '');
  return t;
}
const PHRASES = [[/\b(?:please|kindly)\s+/gi, ''], [/\bI (?:would like|want|need) you to\s+/gi, ''], [/\bin order to\b/gi, 'to'], [/\bdue to the fact that\b/gi, 'because'],
  [/\bat this point in time\b/gi, 'now'], [/\bin the event that\b/gi, 'if'], [/\bit is (?:important|worth) (?:to note|noting) that\s*/gi, ''], [/\bas well as\b/gi, 'and'],
  [/\ba (?:large |great )?number of\b/gi, 'many'], [/\bthe fact that\b/gi, 'that'], [/\bwith (?:regard|respect) to\b/gi, 'on'], [/\bfor example\b/gi, 'e.g.'],
  [/\bin addition,?\s*/gi, 'also '], [/\bhowever,\s*/gi, 'but '], [/\btherefore,\s*/gi, 'so '], [/\bapproximately\b/gi, '~'], [/\bin particular\b/gi, 'esp.']];
function prose3(t) {
  return t.split('\n').map((line) => {
    if (/[\\$=^_{}<>|`]/.test(line) || line.split(/\s+/).length < 6) return line;
    for (const [r, s] of PHRASES) line = line.replace(r, s);
    return line.replace(/\b(?:the|a|an)\s+(?=\S)/gi, '');
  }).join('\n');
}
function stripComments(c, lang) {
  let re = null;
  if (SLASH.has(lang)) re = /^\s*\/\/.*$/gm; else if (HASH.has(lang)) re = /^\s*#(?!!|\s*(?:include|define|pragma|if|endif|else)).*$/gm;
  return re ? c.replace(re, '').replace(/\n{2,}/g, '\n') : c;
}

export function normalizeText(text, { level = 2, role = 'user', seen = null, dedupe = false } = {}) {
  text = text.replace(/\r\n?/g, '\n');
  const whole = tryJson(text); if (whole !== null) return whole;
  const parts = splitFences(text).map((p) => {
    if (p.code) {
      if (p.lang === 'json') { const j = tryJson(p.text); if (j !== null) return { ...p, text: j + '\n' }; }
      let c = p.text.replace(/[ \t]+$/gm, '').replace(/\n{3,}/g, '\n\n');
      if (level >= 3) c = stripComments(c, p.lang);
      return { ...p, text: c };
    }
    let t = prose1(p.text);
    if (level >= 2) t = prose2(t, role);
    if (level >= 3) t = prose3(t);
    if (level >= 2 && seen) {
      t = t.split(/\n{2,}/).map((para) => {
        const key = para.toLowerCase().replace(/\s+/g, ' ').trim();
        if (key.length < 60) return para;
        if (dedupe && seen.has(key)) return '[dup omitted]';
        seen.add(key); return para;
      }).join('\n\n');
    }
    return { ...p, text: t };
  });
  return joinFences(parts).trim();
}

// ---- query-aware extractive pruning (lossy) ----
const WORD = /[\p{L}\d]{3,}/gu;
function unitsOf(text) {
  const out = [];
  for (const p of splitFences(text)) {
    if (p.code) { out.push({ t: '```' + p.lang + '\n' + p.text + '```', code: true }); continue; }
    for (const line of p.text.split('\n')) {
      const l = line.trim(); if (!l) continue;
      if (estimateTokens(l) > 80) for (const s of l.split(/(?<=[.!?])\s+/)) { if (s.trim()) out.push({ t: s.trim() }); } else out.push({ t: l });
    }
  }
  return out;
}
function pruneOnce(text, query, target) {
  const U = unitsOf(text); const toks = U.map((u) => estimateTokens(u.t) + 1); // +1 for the joining newline
  if (toks.reduce((a, b) => a + b, 0) <= target) return text;
  const terms = [...new Set((query.toLowerCase().match(WORD) || []).filter((w) => !STOP.has(w)))];
  const dt = U.map((u) => (u.t.toLowerCase().match(WORD) || []).filter((w) => !STOP.has(w)));
  const df = new Map(); for (const ws of dt) for (const w of new Set(ws)) df.set(w, (df.get(w) || 0) + 1);
  const N = U.length, idf = (w) => Math.log(1 + N / (1 + (df.get(w) || 0)));
  const score = U.map((u, i) => {
    const tf = {}; for (const w of dt[i]) tf[w] = (tf[w] || 0) + 1;
    const len = dt[i].length || 1;
    const rel = terms.reduce((s, w) => (tf[w] ? s + idf(w) * (1 + Math.log(tf[w])) : s), 0);
    const info = [...new Set(dt[i])].reduce((s, w) => s + idf(w), 0) / Math.sqrt(len);
    let s = (terms.length ? 2 * rel / Math.sqrt(len + 4) : 0) + 0.3 * info;
    if (/^(#{1,6}\s|\d+(\.\d+)*\s+[A-Z]|\\(sub)*section)/.test(u.t)) s += 1.5;
    if (/\b(definition|theorem|proposition|lemma|conclusion|summary|abstract|note)\b/i.test(u.t)) s += 1;
    if (/\d|[=<>]/.test(u.t)) s += 0.4;
    if (u.code) s += 0.5;
    if (i < 2) s += 5; if (i === U.length - 1) s += 1.5;
    return s;
  });
  let used = 0; const keep = new Set();
  for (const i of score.map((s, i) => i).sort((a, b) => score[b] - score[a])) { if (used + toks[i] <= target) { keep.add(i); used += toks[i]; } }
  const out = []; let gap = false;
  for (let i = 0; i < U.length; i++) { if (keep.has(i)) { if (gap && out.length) out.push('[...]'); out.push(U[i].t); gap = false; } else gap = true; }
  if (gap) out.push('[...]');
  return out.join('\n');
}

export function pruneText(text, { query = '', target = 500 } = {}) {
  let t = target, out = pruneOnce(text, query, t);
  for (let i = 0; i < 12 && estimateTokens(out) > target && t > 20; i++) { t = Math.floor(t * 0.92); out = pruneOnce(text, query, t); } // gap markers cost tokens too
  return out;
}

// ---- message-level compression ----
const mapContent = (c, fn) => (typeof c === 'string' ? fn(c) : Array.isArray(c) ? c.map((p) => (p && p.type === 'text' && typeof p.text === 'string' ? { ...p, text: fn(p.text) } : p)) : c);
export const contentText = (c) => (typeof c === 'string' ? c : Array.isArray(c) ? c.map((p) => (p && p.type === 'text' ? p.text : '')).join('\n') : '');
const msgTokens = (m) => estimateTokens(contentText(m.content)) + 4;
const total = (ms) => ms.reduce((a, m) => a + msgTokens(m), 0);

export const PRESETS = {
  light: { level: 1, oldCap: 0, docCap: 0 },
  balanced: { level: 2, oldCap: 250, docCap: 0 },
  max: { level: 3, oldCap: 80, docCap: 2000, terse: true },
};

/** compress(messages, {preset|level, keepLast, oldCap, docCap, maxInputTokens, terse}) -> {messages, stats} */
export function compress(messages, o = {}) {
  const opt = { keepLast: 4, maxInputTokens: 0, terse: false, ...PRESETS[o.preset || 'balanced'], ...o };
  const before = total(messages);
  const lastUser = messages.map((m) => m.role).lastIndexOf('user');
  const query = lastUser >= 0 ? contentText(messages[lastUser].content) : '';
  const norm = (level) => { const seen = new Set(); return messages.map((m, i) => ({ ...m, content: mapContent(m.content, (t) => normalizeText(t, { level: i === lastUser ? Math.min(level, 2) : level, role: m.role, seen, dedupe: i !== lastUser })) })); };
  let level = opt.level, ms = norm(level);
  const prune = (i, cap, q) => { ms[i] = { ...ms[i], content: mapContent(ms[i].content, (t) => pruneText(t, { query: q, target: cap })) }; };
  const oldIdx = ms.map((m, i) => i).filter((i) => ms[i].role !== 'system' && i < ms.length - opt.keepLast && i !== lastUser);
  if (opt.oldCap) for (const i of oldIdx) prune(i, opt.oldCap, query);
  if (opt.docCap) for (let i = 0; i < ms.length; i++) if (i !== lastUser && msgTokens(ms[i]) > opt.docCap) prune(i, opt.docCap, query);
  const B = opt.maxInputTokens;
  if (B && total(ms) > B) {
    if (level < 3) { level = 3; ms = norm(3); if (opt.oldCap) for (const i of oldIdx) prune(i, opt.oldCap, query); }
    for (const cap of [150, 80, 40]) { if (total(ms) <= B) break; for (const i of oldIdx) prune(i, cap, query); }
    for (let guard = 0; total(ms) > B && guard < 20; guard++) {
      let k = -1, best = 0; ms.forEach((m, i) => { if (i !== lastUser && msgTokens(m) > best) { best = msgTokens(m); k = i; } });
      if (k < 0 || best < 60) break;
      prune(k, Math.max(40, Math.floor(best - (total(ms) - B) * 1.1)), query);
    }
    const lastRef = ms[lastUser]; let dropped = 0;
    while (total(ms) > B) { // still over: omit oldest turns (pairs keep role alternation)
      const f = ms.findIndex((m) => m.role !== 'system');
      if (f < 0 || ms.length - f <= opt.keepLast || ms[f] === lastRef) break;
      const n = ms[f + 1] === lastRef ? 1 : 2; ms.splice(f, n); dropped += n;
    }
    if (dropped) { const f = ms.findIndex((m) => m.role !== 'system'); const note = `[${dropped} earlier messages omitted] `; ms[f] = { ...ms[f], content: typeof ms[f].content === 'string' ? note + ms[f].content : [{ type: 'text', text: note }, ...ms[f].content] }; }
    const li = ms.indexOf(lastRef);
    if (total(ms) > B && li >= 0) { const m = ms[li], tail = contentText(m.content).slice(-400); prune(li, Math.max(60, msgTokens(m) - (total(ms) - B)), tail); }
  }
  if (opt.terse) {
    const note = 'Reply tersely: no preamble, no restating the question, no closing summary.';
    const s = ms.findIndex((m) => m.role === 'system');
    if (s >= 0) ms[s] = { ...ms[s], content: mapContent(ms[s].content, (t) => t + '\n' + note) }; else ms.unshift({ role: 'system', content: note });
  }
  const after = total(ms);
  return { messages: ms, stats: { before, after, saved: before - after, pct: before ? +(100 * (before - after) / before).toFixed(1) : 0, level } };
}

/** compressText(text, {level, query, budget}) for single documents/prompts. */
export function compressText(text, { level = 2, query = '', budget = 0 } = {}) {
  const before = estimateTokens(text); let out = normalizeText(text, { level });
  if (budget && estimateTokens(out) > budget) out = pruneText(normalizeText(text, { level: 3 }), { query, target: budget });
  const after = estimateTokens(out);
  return { text: out, stats: { before, after, saved: before - after, pct: before ? +(100 * (before - after) / before).toFixed(1) : 0 } };
}
