import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { compress, compressText, normalizeText, pruneText, estimateTokens } from '../src/squeeze.js';
import { Cache } from '../src/cache.js';
import { createProxy } from '../src/proxy.js';

test('JSON is minified losslessly', () => {
  const src = '{\n  "a": [1, 2,   3],\n  "b": {"c": "x  y"}\n}';
  assert.deepEqual(JSON.parse(normalizeText(src, { level: 3 })), JSON.parse(src));
  assert.ok(normalizeText(src).length < src.length);
});

test('fenced code is preserved at level 2 (only trailing space/blank-line cleanup)', () => {
  const code = 'function f(a,  b) {\n  // keep me\n  return a +  b;\n}\n';
  const out = normalizeText('Intro   text\n\n\n\n```js\n' + code + '```\nend', { level: 2 });
  assert.ok(out.includes(code));
});

test('numbers and equations survive level 3', () => {
  const src = 'F(x) = 3.14159 at x* = 42 and rate 0.0013.\nPlease note that the value is a number of things in order to converge for the system as well as the rest.';
  const out = normalizeText(src, { level: 3 });
  for (const n of src.match(/\d+(\.\d+)?/g)) assert.ok(out.includes(n), n);
  assert.ok(estimateTokens(out) < estimateTokens(src));
});

test('cross-message duplicate paragraphs are dropped, last user message untouched', () => {
  const big = 'This is a long repeated paragraph that appears in the system prompt and again later in the conversation verbatim.';
  const r = compress([{ role: 'system', content: big }, { role: 'user', content: 'q1' }, { role: 'assistant', content: 'a1' }, { role: 'user', content: big }], { preset: 'balanced' });
  assert.equal(r.messages[3].content, big);
  const r2 = compress([{ role: 'system', content: big }, { role: 'user', content: big }, { role: 'user', content: 'final' }]);
  assert.equal(r2.messages[1].content, '[dup omitted]');
});

test('query-aware pruning keeps the relevant sentence', () => {
  const filler = Array.from({ length: 60 }, (_, i) => `Filler sentence number ${i} about nothing in particular here.`).join('\n');
  const text = 'Title line\n' + filler + '\nThe zebra stampede threshold is exactly 17 animals.\n' + filler;
  const out = pruneText(text, { query: 'what is the zebra stampede threshold', target: 120 });
  assert.ok(out.includes('zebra stampede threshold is exactly 17'));
  assert.ok(estimateTokens(out) <= 150);
});

test('budget is met and the current user turn is intact', () => {
  const msgs = [{ role: 'system', content: 'You are helpful.' }];
  for (let i = 0; i < 20; i++) { msgs.push({ role: 'user', content: `question ${i} ` + 'context words go here and there. '.repeat(60) }); msgs.push({ role: 'assistant', content: `answer ${i} ` + 'long reply content with details. '.repeat(80) }); }
  msgs.push({ role: 'user', content: 'What was the final answer about topic seven?' });
  const r = compress(msgs, { maxInputTokens: 1500 });
  assert.ok(r.stats.after <= 1500, `after=${r.stats.after}`);
  assert.equal(r.messages.at(-1).content, 'What was the final answer about topic seven?');
  assert.ok(r.stats.pct > 80);
});

test('content-block arrays are handled', () => {
  const r = compress([{ role: 'user', content: [{ type: 'text', text: 'a   b\n\n\n\nc' }, { type: 'image_url', image_url: { url: 'x' } }] }], { preset: 'light' });
  assert.equal(r.messages[0].content[0].text, 'a b\n\nc'); assert.equal(r.messages[0].content[1].type, 'image_url');
});

test('cache is LRU with TTL', async () => {
  const c = new Cache({ max: 2, ttlMs: 30 }); c.set('a', 1); c.set('b', 2); c.get('a'); c.set('c', 3);
  assert.equal(c.get('b'), null); assert.equal(c.get('a'), 1);
  await new Promise((r) => setTimeout(r, 50)); assert.equal(c.get('a'), null);
});

test('proxy compresses requests, forwards, caches repeats', async () => {
  let calls = 0, seen = null;
  const up = http.createServer(async (req, res) => { const ch = []; for await (const c of req) ch.push(c); seen = JSON.parse(Buffer.concat(ch)); calls++; res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ choices: [{ message: { content: 'hi' } }], usage: { prompt_tokens: 10, completion_tokens: 5 } })); });
  await new Promise((r) => up.listen(0, r));
  const { server, stats } = createProxy({ SQUEEZE_UPSTREAM: `http://127.0.0.1:${up.address().port}` });
  await new Promise((r) => server.listen(0, r)); const base = `http://127.0.0.1:${server.address().port}`;
  const body = JSON.stringify({ model: 'm', temperature: 0, messages: [{ role: 'user', content: 'Hello   there\n\n\n\n\n**bold**   text' }] });
  const call = () => fetch(base + '/v1/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json' }, body });
  const r1 = await call(); assert.equal(r1.headers.get('x-squeeze-cache'), 'miss'); await r1.text();
  assert.equal(seen.messages[0].content, 'Hello there\n\nbold text');
  const r2 = await call(); assert.equal(r2.headers.get('x-squeeze-cache'), 'hit'); await r2.text();
  assert.equal(calls, 1); assert.equal(stats.cache_hits, 1);
  server.close(); up.close();
});
