import http from 'node:http';
import { Readable } from 'node:stream';
import { compress, estimateTokens, contentText, normalizeText } from './squeeze.js';
import { Cache } from './cache.js';

/** Compressing reverse proxy for any OpenAI-/Anthropic-compatible API (chat completions, messages). */
export function createProxy(env = process.env) {
  const upstream = (env.SQUEEZE_UPSTREAM || '').replace(/\/+$/, '');
  const opts = { preset: env.SQUEEZE_PRESET || 'balanced', maxInputTokens: Number(env.SQUEEZE_MAX_INPUT_TOKENS || 0), terse: env.SQUEEZE_TERSE === '1' || undefined };
  const maxTemp = Number(env.SQUEEZE_CACHE_MAX_TEMP ?? 0.3);
  const cache = env.SQUEEZE_CACHE === '0' ? null : new Cache({ max: Number(env.SQUEEZE_CACHE_MAX || 500), file: env.SQUEEZE_CACHE_FILE || '' });
  const token = env.SQUEEZE_TOKEN || '';
  const st = { requests: 0, tokens_before: 0, tokens_after: 0, cache_hits: 0, cache_tokens_saved: 0, upstream_prompt_tokens: 0, upstream_completion_tokens: 0 };
  const send = (res, code, obj, headers = {}) => { const b = JSON.stringify(obj, null, 2); res.writeHead(code, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(b), ...headers }); res.end(b); };
  const squeezeBody = (body) => {
    let stats = null;
    if (Array.isArray(body.messages)) { const r = compress(body.messages, opts); body.messages = r.messages; stats = r.stats; }
    if (body.system) { // Anthropic-style top-level system
      const b = typeof body.system === 'string' ? estimateTokens(body.system) : estimateTokens(contentText(body.system));
      body.system = typeof body.system === 'string' ? normalizeText(body.system, { level: 2 }) : body.system.map((p) => (p?.type === 'text' ? { ...p, text: normalizeText(p.text, { level: 2 }) } : p));
      const a = typeof body.system === 'string' ? estimateTokens(body.system) : estimateTokens(contentText(body.system));
      if (stats) { stats.before += b; stats.after += a; stats.saved += b - a; }
    }
    return stats;
  };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    if (token && url.pathname.startsWith('/squeeze') === false && (req.headers['x-squeeze-token'] || '') !== token) return send(res, 401, { error: 'bad x-squeeze-token' });
    if (req.method === 'GET' && url.pathname === '/squeeze/stats') return send(res, 200, { ...st, saved_tokens_est: st.tokens_before - st.tokens_after + st.cache_tokens_saved, cache_size: cache?.size ?? 0 });
    const chunks = []; let size = 0;
    for await (const c of req) { size += c.length; if (size > 20e6) return send(res, 413, { error: 'body too large' }); chunks.push(c); }
    const raw = Buffer.concat(chunks);
    if (req.method === 'POST' && url.pathname === '/squeeze/preview') {
      try { const b = JSON.parse(raw.toString()); const s = squeezeBody(b); return send(res, 200, { ...b, squeeze_stats: s }); } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (!upstream) return send(res, 500, { error: 'Set SQUEEZE_UPSTREAM, e.g. https://api.openai.com' });
    let body = null, stats = null, ckey = null;
    if (req.method === 'POST' && /json/.test(req.headers['content-type'] || '')) { try { body = JSON.parse(raw.toString()); } catch { /* forward as-is */ } }
    if (body) {
      stats = squeezeBody(body); st.requests++;
      if (stats) { st.tokens_before += stats.before; st.tokens_after += stats.after; }
      const cacheable = cache && !body.stream && (body.temperature ?? 1) <= maxTemp;
      if (cacheable) {
        ckey = Cache.key({ p: url.pathname, b: body }); const hit = cache.get(ckey);
        if (hit) { st.cache_hits++; st.cache_tokens_saved += (stats?.after || 0) + (hit.out || 0); return res.writeHead(hit.status, { 'content-type': hit.ct, 'x-squeeze-cache': 'hit', 'x-squeeze-saved-tokens': String((stats?.saved || 0) + (stats?.after || 0) + (hit.out || 0)) }), res.end(hit.text); }
      }
    }
    const headers = {}; for (const [k, v] of Object.entries(req.headers)) if (!['host', 'content-length', 'connection', 'accept-encoding', 'x-squeeze-token'].includes(k)) headers[k] = v;
    if (env.SQUEEZE_UPSTREAM_KEY) headers.authorization = `Bearer ${env.SQUEEZE_UPSTREAM_KEY}`;
    try {
      const up = await fetch(upstream + req.url, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : (body ? JSON.stringify(body) : raw) });
      const ct = up.headers.get('content-type') || 'application/json';
      const sq = { 'x-squeeze-tokens-before': String(stats?.before ?? 0), 'x-squeeze-tokens-after': String(stats?.after ?? 0), 'x-squeeze-saved-tokens': String(stats?.saved ?? 0), 'x-squeeze-cache': 'miss' };
      if (body?.stream || /event-stream/.test(ct)) { res.writeHead(up.status, { 'content-type': ct, ...sq }); return Readable.fromWeb(up.body).pipe(res); }
      const text = await up.text(); let out = 0;
      try { const j = JSON.parse(text); const u = j.usage || {}; st.upstream_prompt_tokens += u.prompt_tokens || u.input_tokens || 0; out = u.completion_tokens || u.output_tokens || 0; st.upstream_completion_tokens += out; } catch { /* non-JSON */ }
      if (ckey && up.ok) cache.set(ckey, { status: up.status, ct, text, out });
      res.writeHead(up.status, { 'content-type': ct, ...sq }); res.end(text);
    } catch (e) { send(res, 502, { error: `upstream failed: ${e.message}` }); }
  });
  return { server, cache, stats: st };
}
