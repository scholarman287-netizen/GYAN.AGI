import crypto from 'node:crypto';
import fs from 'node:fs';

/** LRU + TTL response cache. A hit costs 0 model tokens. Optional JSON persistence. */
export class Cache {
  constructor({ max = 500, ttlMs = 86400000, file = '' } = {}) {
    Object.assign(this, { max, ttlMs, file }); this.map = new Map(); this.timer = null;
    if (file && fs.existsSync(file)) { try { for (const [k, v] of JSON.parse(fs.readFileSync(file, 'utf8'))) this.map.set(k, v); } catch { /* ignore corrupt cache */ } }
  }
  static key(obj) { return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex'); }
  get(k) {
    const e = this.map.get(k); if (!e) return null;
    if (Date.now() - e.t > this.ttlMs) { this.map.delete(k); return null; }
    this.map.delete(k); this.map.set(k, e); return e.v;
  }
  set(k, v) {
    this.map.set(k, { t: Date.now(), v });
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
    if (this.file && !this.timer) this.timer = setTimeout(() => { this.timer = null; try { fs.writeFileSync(this.file, JSON.stringify([...this.map])); } catch { /* ignore */ } }, 2000).unref();
  }
  get size() { return this.map.size; }
}
